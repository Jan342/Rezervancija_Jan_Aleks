create function registration_insert(username_reg character varying, password_reg character varying, email_reg character varying) returns void
    language plpgsql
as
$$BEGIN

    INSERT INTO uporabniki (username, password, email)
    VALUES(username_reg,password_reg,email_reg);

END
$$;

alter function registration_insert(varchar, varchar, varchar) owner to alekshj2004;

