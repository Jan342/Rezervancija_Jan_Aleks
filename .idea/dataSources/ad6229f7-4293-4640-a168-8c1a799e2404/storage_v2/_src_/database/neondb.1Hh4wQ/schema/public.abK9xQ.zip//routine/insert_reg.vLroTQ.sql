create function insert_reg(username_reg character varying, password_reg character varying, email_reg character varying) returns void
    language plpgsql
as
$$BEGIN

    insert into "Uporabniki" (username, password, email)
    values(username_reg,password_reg,email_reg);

END;
$$;

alter function insert_reg(varchar, varchar, varchar) owner to alekshj2004;

