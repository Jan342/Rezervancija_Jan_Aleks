create function username_uporabnika(usernames character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    user_count integer;
BEGIN
    SELECT count(*) INTO user_count FROM uporabniki WHERE username = $1;
    RETURN user_count > 0;
END;
$$;

alter function username_uporabnika(varchar) owner to alekshj2004;

